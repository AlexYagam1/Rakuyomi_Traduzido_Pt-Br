local _ = require("gettext")

return {
  name = "Rakuyomi Pt-Br",
  fullname = _("Rakuyomi Pt-Br"),
  description = _("Baixe mangá no seu leitor de E-books!")
}
