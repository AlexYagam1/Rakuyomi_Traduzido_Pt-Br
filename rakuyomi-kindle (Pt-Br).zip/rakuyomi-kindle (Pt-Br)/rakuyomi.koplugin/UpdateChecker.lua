local ButtonDialog = require("ui/widget/buttondialog")
local UIManager = require("ui/uimanager")
local InfoMessage = require("ui/widget/infomessage")
local NetworkMgr = require("ui/network/manager")
local Trapper = require("ui/trapper")
local _ = require("gettext")

local Backend = require("Backend")
local ErrorDialog = require("ErrorDialog")
local Icons = require("Icons")
local LoadingDialog = require("LoadingDialog")

local UpdateChecker = {}

function UpdateChecker:checkForUpdates()
  if not NetworkMgr:isConnected() then
    ErrorDialog:show(_("Impossível checar atualizaçãoes no modo offline"))
    return
  end

  local response = Backend.checkForUpdates()

  if response.type == "ERROR" then
    ErrorDialog:show(response.message)
    return
  end

  --- @type UpdateInfo
  local update_info = response.body
  if not update_info.available then
    UIManager:show(InfoMessage:new {
      text = _("Sua versão já está atualizada!")
    })
    return
  end

  local dialog

  local dialog_title
  local buttons
  if update_info.auto_installable then
    dialog_title = string.format(
      _("Nova versão %s está disponível. Você está usando a versão %s.\n\nDeseja atualizar agora?"),
      update_info.latest_version,
      update_info.current_version or "unknown"
    )

    buttons = {
      {
        {
          text = _("Depois"),
          callback = function()
            UIManager:close(dialog)
          end
        },
        {
          text = _("Atualizar"),
          callback = function()
            UIManager:close(dialog)
            self:installUpdate(update_info.latest_version)
          end
        }
      }
    }
  else
    dialog_title = string.format(
      _(
        "Nova versão %s está disponível. Você está usando a versão %s.\n\n" ..
        "Esta atualização não pode ser instalada automaticamente, visite o guia de usuários para mais instruções."),
      update_info.latest_version,
      update_info.current_version or "unknown"
    )

    buttons = {
      {
        {
          text = _("OK"),
          callback = function()
            UIManager:close(dialog)
          end
        }
      }
    }
  end

  dialog = ButtonDialog:new {
    title = dialog_title,
    buttons = buttons
  }

  UIManager:show(dialog)
end

function UpdateChecker:installUpdate(version)
  Trapper:wrap(function()
    local response = LoadingDialog:showAndRun(
      _("Atualizando Rakuyomi, Aguarde..."),
      function()
        return Backend.installUpdate(version)
      end
    )

    if response.type == "ERROR" then
      ErrorDialog:show(response.message)
      return
    end

    local dialog
    -- Show success and prompt for restart
    local buttons = {
      {
        {
          text = _("Reiniciar agora"),
          callback = function()
            UIManager:close(dialog)

            self:showMessageAndRestart()
          end
        }
      }
    }

    dialog = ButtonDialog:new {
      title = _("Atualização instalada com sucesso. KOReader precisa ser reiniciado para executar mudanças."),
      buttons = buttons
    }

    UIManager:show(dialog)
  end)
end

function UpdateChecker:showMessageAndRestart()
  UIManager:show(InfoMessage:new {
    text = _("Reiniciando..."),
    dismissable = false,
  })

  UIManager:nextTick(function()
    UIManager:restartKOReader()
  end)
end

return UpdateChecker
